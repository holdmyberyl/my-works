<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "student_system";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Database connected successfully!";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Config Test</title>
    <style>
        body { background: #fff; color: #000; font-family: Arial, sans-serif; text-align: center; padding-top: 50px; }
    </style>
</head>
<body>
</body>
</html>
