CREATE DATABASE student_system;
DROP DATABASE student_system;
USE student_system;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,        
    username VARCHAR(50) UNIQUE NOT NULL,     
    password VARCHAR(255) NOT NULL,           
    profile_pic VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP 
);
INSERT INTO users (username, password)
VALUES ('francois', '$2y$10$9YvCh8jIPUYu2in8YZOuWefBHFGX4DCc14uFqM9EmroyzJ9qcDmBW');

DROP TABLE users;	
