<?php
session_start();
require 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$message = "";

$sql = "SELECT profile_pic FROM users WHERE id=$user_id LIMIT 1";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$current_pic = $row['profile_pic'] ?? 'default.png';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['profile_pic'])) {
    $file = $_FILES['profile_pic'];
    $fileName = $file['name'];
    $fileTmp = $file['tmp_name'];
    $fileSize = $file['size'];
    $allowed = ['jpg','jpeg','png'];
    $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) $message = "Only JPG and PNG files allowed.";
    elseif ($fileSize > 2*1024*1024) $message = "File size must be below 2MB.";
    else {
        $newName = "profile_".$user_id."_".time().".".$ext;
        if (move_uploaded_file($fileTmp, "uploads/".$newName)) {
            $conn->query("UPDATE users SET profile_pic='$newName' WHERE id=$user_id");
            $current_pic = $newName;
            $message = "Profile picture updated!";
        } else $message = "Upload failed.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        body { background: #fff; color: #000; font-family: Arial; text-align: center; padding-top: 50px; }
        input { padding: 5px; margin: 5px; }
        button { padding: 5px 10px; margin-top: 10px; cursor: pointer; }
        img { border-radius: 50%; object-fit: cover; }
        a { color: #000; text-decoration: none; }
    </style>
</head>
<body>

<h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
<img src="uploads/<?php echo $current_pic; ?>" width="150" height="150"><br><br>

<form method="POST" enctype="multipart/form-data">
    <input type="file" name="profile_pic" required><br><br>
    <button type="submit">Change Profile Picture</button>
</form>

<p style="color:green;"><?php echo $message; ?></p>

<br><a href="logout.php">Logout</a>

</body>
</html>
