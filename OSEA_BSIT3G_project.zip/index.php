<!DOCTYPE html>
<html>
<head>
    <title>Student Information System</title>
    <style>
        body {
            background: #fff;
            color: #000;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 100px;
        }
        h1 {
            font-size: 32px;
            margin-bottom: 50px;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border: 1px solid #000;
            background: #fff;
            color: #000;
        }
        button:hover {
            background: #000;
            color: #fff;
        }
        a {
            text-decoration: none;
        }
    </style>
</head>
<body>

<h1>Student Information System</h1>

<a href="login.php"><button>Login</button></a>

</body>
</html>
